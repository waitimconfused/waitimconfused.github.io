let discordButtons = document.getElementsByTagName("discordButton");

for (let i = 0; i < discordButtons.length; i++) {
  discordButtons[i].setAttribute(
    "onclick",
    "Discord_Open("+
    JSON.stringify(
        discordButtons[i].getAttribute("invite")
        )+
    ")"
  );
}
function Discord_Open(inviteCODE){
    if(confirm("WARNING:\nYou're about to leave PIXLUS!\n       Are you sure you want to do so?")){
        window.open("https://discord.com/invite/"+inviteCODE)
    }
}