function myFunction(colour) {
    var copyText = document.getElementById(colour);
    copyText.value = copyText.getAttribute("hex");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value);
    copyText.value = null;
  }