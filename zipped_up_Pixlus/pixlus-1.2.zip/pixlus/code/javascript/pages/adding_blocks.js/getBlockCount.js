let blockCount = Object.keys(presetBlockLayer).length - 1;

let blockCountElements = document.getElementsByClassName("blockCount");
let blockCountAddOne = document.getElementsByClassName("blockCountAddOne");
let blockLayer = document.getElementsByClassName("blockLayer");
let STRINGblockCountElements = document.getElementsByClassName("STRINGblockCount");
let STRINGblockCountAddOne = document.getElementsByClassName("STRINGblockCountAddOne");

for (let index = 0; index < blockCountElements.length; index++) {
    blockCountElements[index].innerHTML = blockCount;
}

for (let index = 0; index < blockCountAddOne.length; index++) {
    blockCountAddOne[index].innerHTML = (blockCount + 1);
}
for (let index = 0; index < STRINGblockCountElements.length; index++) {
    STRINGblockCountElements[index].innerHTML = `"`+blockCount+`"`;
}

for (let index = 0; index < STRINGblockCountAddOne.length; index++) {
    STRINGblockCountAddOne[index].innerHTML = `"`+(blockCount + 1)+`"`;
}

document.getElementsByClassName("blockLayer")[0].innerHTML = JSON.stringify(presetBlockLayer[blockCount]);
let randomBlockName = [
	"Moss",
	"Pile of sticks",
	"Wooden Desk",
	"This Is A Randomly Genorated Block Name",
	"Potato Patch",
	"Bread"
]
document.getElementById("randomLayer").innerHTML = `{"layer":`+randomIntFromInterval(1,3)+`,"name":"`+randomBlockName[randomIntFromInterval(0,randomBlockName.length-1)]+`"}`;

function GetBlockLayer(indx){
	if(presetBlockLayer.hasOwnProperty(indx)){
		if(presetBlockLayer[indx].layer < 4){
			return(presetBlockLayer[indx].layer);
		}else{
			return(3);
		}
	}else{
		return(false);
	}
}
function GetBlockName(indx){
	if(presetBlockLayer.hasOwnProperty(indx)){
		return(presetBlockLayer[indx].name);
	}else{
		return(false);
	}
}

function randomIntFromInterval(min, max){ 
    return Math.floor(Math.random() * (max - min + 1) + min)
  }
  