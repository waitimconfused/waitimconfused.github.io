var pixlus = window;
function launch(){
    let data = {
    width: 1500,
    height: 1500,
    pos:{
        x: screen.width/2,
        y: screen.height/2,
    }
    };
    pixlus.open(`pages/game.html`,`pixlus`,`width=1500,height=1500`);
    pixlus.resizeTo(data.pos.x, data.pos.y);
    pixlus.moveTo(data.pos.x  -data.width/2, data.pos.y  -data.height/2);
    pixlus.blur();
}
function scrollAnimation(){
    let PIXLUS = document.getElementsByTagName("h1")[0];
    PIXLUS.style.left = window.scrollY;
}
window.addEventListener("scroll", scrollAnimation);
function scrollDown(){
    let CustomOffset = {
        x: 0,
        y: -24
    }
    if(window.scrollY < window.innerHeight + CustomOffset.y){
        window.scrollTo(0, window.innerHeight + CustomOffset.y);
    }
}
function wait(ms){
    var start = new Date().getTime();
    var end = start;
    while(end < start + ms) {
        end = new Date().getTime();
    }
}

// Detects if the user should be able to re-install PIXLUS (Online vs Offline)
let appendLocation = document.getElementsByClassName("bg-text")[0];
let reInstall = document.createElement("a");
window.onload = function(){
    if(navigator.onLine){
        online();
    }
};
window.addEventListener('online',  online());
window.addEventListener('offline', offline());
function online(){
    reInstall.setAttribute("href","https://Dev-384.github.io/pixlus/download");
    reInstall.setAttribute("class","launchButton");
    reInstall.innerHTML = "Re-Install";
    appendLocation.appendChild(reInstall);
};
function offline(){
    reInstall.remove();
};