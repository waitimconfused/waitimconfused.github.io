var player = {
	pause: {
		paused: true,
		reason: "paused",
	},
	speech: {
		step: 0,
		text: [
			"Hello...",
			"World!"
		],
		isPlayerSpeaking: true
	},
	frame: 1,
	animationSpeed: 500,
	pos: {
		x: 10,
		y: 3,
		hover: {
			x: 0,
			y: 0,
			showHover: true
		},
		mouse: {
			x: 0,
			y: 0,
			click: false,
		},
		start:{
			x: 10,
			y: 3.25,
		},
	},
	switchWorld: false,
	direction:"left",
	movement: "idle",
    facing: [null,],
	lastKey: null,
	speed: 16/4,
	size: 2,
	hoverBlock: true,
	fps:24,
	invontory:{

	},
	notifications:{
		active:[],
		past:[],
		notificationState:0,
	},
}
// PLAYER MOVEMENTS
addEventListener("keydown", function(e){
	let key = e.key;
	player.lastKey = key
	if(key == "Escape"){
		if(gameInfo.player.lock.isOn){
			let password = prompt("PIXLUS has been locked.\nPlease enter your PIXLUS password:", "");
			if(password == gameInfo.player.password){
				gameInfo.player.lock.isOn = false;
			}
		}
		if(player.pause.paused){
			player.pause.paused = false;
			setCursor("clickable");
			player.pause.reason = null;
		}else{
			player.pause.paused = true;
			player.pause.reason = "paused";
			setCursor("pointer");
		}
	}

	if(player.pause.paused !== true){
		player.lastKey = key.toLowerCase();
		var nothingBlocks = [null,undefined,"017","035","081","127"];
		if(key.toLowerCase() === "w" || key === 'ArrowUp'){
            player.facing.push("up");
			player.movement = "walk";
		}
		if(key.toLowerCase() === "s" || key.includes("ArrowDown")){
            player.facing.push("down");
			player.movement = "walk";
		}
		if(key.toLowerCase() === "a" || key.includes("ArrowLeft")){
            player.facing.push("left");
			player.movement = "walk";
		}
		if(key.toLowerCase() === "d" || key.includes("ArrowRight")){
            player.facing.push("right");
			player.movement = "walk";
		}
		let sizeLimit = {
			s: 1,
			l: 50
		};
		if(key.includes("=")){
			player.size += 1;
			if(player.size > sizeLimit.l){
				player.size = sizeLimit.l;
			}
		}
		if(key.includes("-")){
			player.size -= 1;
			if(player.size < sizeLimit.s){
				player.size = sizeLimit.s;
			}
		}
		if(key.includes("+")){
			player.size += 0.5;
			if(player.size > sizeLimit.l){
				player.size = sizeLimit.l;
			}
		}
		if(key.includes("_")){
			player.size -= 0.5;
			if(player.size < sizeLimit.s){
				player.size = sizeLimit.s;
			}
		}
		let worldSwitchLoop = setInterval(() => {
			var world = document.getElementById("world");
			var CurrentWorld = JSON.parse(localStorage.getItem("world-"+world.value));
			var WorldSwitchBlocks = ["080","156","169","170","171","187","188","189"];
			player.switchWorld = false;
			if(player.pos.y < CurrentWorld.back.length && player.pos.y < CurrentWorld.middle.length){
				if(WorldSwitchBlocks.includes(CurrentWorld.back[Math.round(player.pos.y)][Math.round(player.pos.x)]) || WorldSwitchBlocks.includes(CurrentWorld.middle[Math.round(player.pos.y)][Math.round(player.pos.x)])){
					player.switchWorld = true;
				}
			}
		}, 500);
		if(key.includes(" ")){
			if(player.switchWorld){
				if(document.getElementById("world").value == 1){
					document.getElementById("world").value = 2;
				}else if(document.getElementById("world").value == 2){
					document.getElementById("world").value = 1;
				}
				player.pos.x = player.pos.start.x;
				player.pos.y = player.pos.start.y;
				player.lastKey = [null];
			}
		}
		if(e.altKey && (gameInfo.devModeTrue || gameInfo.mapCreator)){
			player.pos.x = player.pos.start.x;
			player.pos.y = player.pos.start.y;
			if(document.getElementById("world").value == 1){
				document.getElementById("world").value = 2;
			}else if(document.getElementById("world").value == 2){
				document.getElementById("world").value = 1;
			}
		}

        if(player.facing.includes("up") && player.movement === "walk"){
            player.pos.y -= 1 / 16 * player.speed;
            if(player.pos.y < 0){
				player.pos.y += 1 / 16 * player.speed;
				player.movement.pop("up");
			}
        }
		if(player.facing.includes("left") && player.movement === "walk"){
            player.pos.x -= 1 / 16 * player.speed;
			player.direction = "left";
            if(player.pos.x < 0){
				player.pos.x += 1 / 16 * player.speed;
				player.movement.pop("left");
			}
        }
        if(player.facing.includes("right")&& player.movement === "walk"){
            player.pos.x += 1 / 16 * player.speed;
			player.direction = "right";

			var world = document.getElementById("world");
			var CurrentWorld = JSON.parse(localStorage.getItem("world-"+world.value));
			var WorldSwitchBlocks = ["080","156","169","170","171","187","188","189"];

			if(player.pos.x > CurrentWorld.middle[Math.round(player.pos.y)].length - 1){
				player.pos.x -= 1 / 16 * player.speed;
				player.movement.pop("right");
			}
        }
        if(player.facing.includes("down") && player.movement === "walk"){
            player.pos.y += 1 / 16 * player.speed;
			var world = document.getElementById("world");
			var CurrentWorld = JSON.parse(localStorage.getItem("world-"+world.value));
			var WorldSwitchBlocks = ["080","156","169","170","171","187","188","189"];
            if(Math.round(player.pos.y) > CurrentWorld.middle.length-1){
				player.pos.y -= 1 / 16 * player.speed;
				player.movement.pop("down");
			}
        }
	}
	if(key.includes("1")){
		sessionStorage.setItem("layer","1");
	}
	if(key.includes("2")){
		sessionStorage.setItem("layer","2");
	}
	if(key.includes("3")){
		sessionStorage.setItem("layer","3");
	}
	let i = 0;
	let text = [
		"Hello...",
		"World!"
	];
	let speechLoop = setInterval(function() {
		if(player.lastKey == 'p'){
			if(player.speech.step < player.speech.text.length){
				speechMode(true,player.speech.isPlayerSpeaking,"Henry",text[player.speech.step]);
				player.speech.step += 1;
			}else{
				speechMode(false);
				player.speech.step = 0;
				player.speech.isPlayerSpeaking = false;
			}
		}
		player.lastKey = null;
		if(player.speech.isPlayerSpeaking){
			player.speech.isPlayerSpeaking = false;
		}else{
			player.speech.isPlayerSpeaking = true;
		}
	},250);
});
document.addEventListener("keyup", function(e){
	player.movement = "idle";
    player.facing.pop(player.lastKey);
	if(player.facing.length = 1){
		player.facing = [null];
	}
});
let playerLoop = setInterval(function() {
		if(player.movement === "idle"){
			if(player.frame > 3){player.frame=3;}
			player.frame = (player.frame + 1) % 3;
			if(player.frame > 3){player.frame=3;}
		}else if(player.movement === "walk"){
			if(player.frame > 6){player.frame=6;}
			player.frame = (player.frame + 1) % 6;
			if(player.frame > 6){player.frame=6;}
		}
},500);
document.addEventListener("mousemove", function(e){
	var innerMouse = {
		X: e.x,
		Y: e.y
	};
	player.pos.mouse.x = innerMouse.X;
	player.pos.mouse.y = innerMouse.Y;
	var MouseBlockX = Math.round((player.pos.mouse.x - canvas.width/2) / 16 / player.size + player.pos.x);
	var MouseBlockY = Math.round((player.pos.mouse.y - canvas.height/2) / 16 / player.size + player.pos.y);
	player.pos.hover.x = MouseBlockX;
	player.pos.hover.y = MouseBlockY;
});