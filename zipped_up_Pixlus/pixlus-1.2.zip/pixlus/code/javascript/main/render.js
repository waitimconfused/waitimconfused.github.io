const id = "display";
var canvas = document.getElementById(id);
var ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;

/*     NOTE
*  The image ['024'] is a placeholder for an empty slot.
*  The image['000'] is allready in use, so I am using a image that will never exist.
*/

var world = document.getElementById("world");
var game = JSON.parse(localStorage.getItem("world-"+world.value));
var blockAnimation = {
	frame: 0,
	info: {
		speed: 100,
		frames: 8
	}
};
//     Game Loop
window.requestAnimationFrame(gameLoop);
function gameLoop(){
	erase(0, 0, canvas.width, canvas.height);
	if(gameInfo.player.lock.isOn){
		player.pause.paused = true;
		document.getElementById("pause").setAttribute("paused",player.pause.paused);
	}
	if(player.pause.paused){
		if(player.pause.reason == "paused"){
			paused();
		}
	}else{
		var world = document.getElementById("world");
		blockBuild();
		var game = JSON.parse(localStorage.getItem("world-"+world.value));
		ctx.textAlign = "center";
		ctx.globalAlpha = 1;
		sendNotification("Welcome, "+gameInfo.player.name,1,false);
		var MouseBlockX = Math.round((player.pos.mouse.x - 390) / 16 / player.size + player.pos.x);
		var MouseBlockY = Math.round((player.pos.mouse.y - 390) / 16 / player.size + player.pos.y);
		player.pos.hover.x = MouseBlockX;
		player.pos.hover.y = MouseBlockY;
		canvas.setAttribute("title",player.pos.hover.x+":"+player.pos.hover.y);
		render();
	}
	function buttonHoverState(x,y,s){
		return(player.pos.mouse.x > x - s/2 && player.pos.mouse.x < x + s/2 && player.pos.mouse.y > y - s*0.5 && player.pos.mouse.y < y + s*0.5)
	}
	function render(){
		blocks(player.pos.x,player.pos.y,player.size,player.pos.hover.showHover);
		blockFunction();
		if(player.notifications.active.length > 0){
			notification();
		}
	}
	function erase(x,y,width,height){
		ctx.clearRect(x, y, x+width, y+height);
	}
	function blocks(posX,posY,size){
		image("blocks/tile"+game.back_fill, canvas.width/2, canvas.height/2, canvas.width,canvas.height);
		for(let backY = 0; backY < game.back.length; backY++){
			for(let backX = 0; backX < game.back[backY].length; backX++){
				var icon = game.back[backY][backX];
				var backPosX = (backX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
				var backPosY = (backY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;

				if(backPosX < canvas.width + 16 * player.size && backPosX > 0 - 16 * player.size){
					if(backPosY < canvas.height + 16 * player.size && backPosY > 0 - 16 * player.size){
							image("blocks/tile"+icon, backPosX, backPosY,(size*16),(size*16));
					}
				}
			}
		}
		for(let middleY=0;middleY < game.middle.length;middleY++){
			for(let middleX = 0; middleX < game.middle[middleY].length; middleX++){
				var icon = game.middle[middleY][middleX];
				var middlePosX = (middleX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
				var middlePosY = (middleY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;

				if(middlePosX < canvas.width + 16 * player.size && middlePosX+1 > 0 - 16 * player.size){
					if(middlePosY < canvas.height + 16 * player.size && middlePosY > 0 - 16 * player.size){
							image("blocks/tile"+icon, middlePosX, middlePosY,(size*16),(size*16));
					}
				}
			}
		}
		if(player.frame > 3){
			player.frame = 0;
		}
		image("player/"+player.movement+"/"+player.direction+"/frame_"+player.frame,canvas.width/2, canvas.height/2,(size*16),(size*16));
		for(let frontY = 0; frontY < game.front.length; frontY++){
			for(let frontX = 0; frontX < game.front[frontY].length; frontX++){
				var icon = game.front[frontY][frontX];
				var frontPosX = (frontX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
				var frontPosY = (frontY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
			
				if(frontPosX < canvas.width + 16 * player.size && frontPosX > 0 - 16 * player.size){
					if(frontPosY < canvas.height + 16 * player.size && frontPosY > 0 - 16 * player.size){
							image("blocks/tile"+icon, frontPosX, frontPosY,(size*16),(size*16));
					}
				}
			}
		}
			if((player.pos.hover.showHover && world.value == 1) || gameInfo.mapCreator){
				var hoverPosX = (player.pos.hover.x*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
				var hoverPosY = (player.pos.hover.y*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
				if(player.pos.hover.y >= 0 && player.pos.hover.x >= 0){
					image("icons/hover",hoverPosX,hoverPosY,16*player.size,16*player.size);
				}else {
					image("icons/hover-decline",hoverPosX,hoverPosY,16*player.size,16*player.size);
				}
				tool("block",sessionStorage.getItem("pickedBlock"));
			}
			// image("icons/treasure_box/frame"+blockAnimation.frame, 100, 100, 64,64);
	}
	canvas.addEventListener("mousedown", function(e){player.pos.mouse.click = true});
	canvas.addEventListener("mouseup", function(e){player.pos.mouse.click = false});
	window.requestAnimationFrame(gameLoop);
};
function blockBuild(){
	if(player.pos.mouse.click && player.pause.paused === false){
		var world = document.getElementById("world");
		if(world.value === "1" || gameInfo.mapCreator){
			var layer = sessionStorage.getItem("layer");
			if(player.pos.hover.y > -1 && player.pos.hover.x > -1){
				let BlockChange = JSON.parse(localStorage.getItem("world-"+world.value));
				if(layer === "1"){
					if(BlockChange.back[player.pos.hover.y]===undefined||BlockChange.back[player.pos.hover.y]===null){
						for(i=0;i<(BlockChange.back.length-player.pos.hover.y);i++){
							BlockChange.back.push(["235"]);
						}
						BlockChange.back[player.pos.hover.y][player.pos.hover.x] = sessionStorage.getItem("pickedBlock");
					}else{
						BlockChange.back[player.pos.hover.y][player.pos.hover.x] = sessionStorage.getItem("pickedBlock");
					}
				}else if(layer === "2"){
					if(BlockChange.middle[player.pos.hover.y]===undefined||BlockChange.middle[player.pos.hover.y]===null){
						for(i=0;i<(player.pos.hover.y-BlockChange.middle.length);i++){
							BlockChange.middle.push(["018"]);
						}
						BlockChange.middle[player.pos.hover.y][0] = sessionStorage.getItem("pickedBlock");
					}else{
						BlockChange.middle[player.pos.hover.y][player.pos.hover.x] = sessionStorage.getItem("pickedBlock");
					}
				}else if(layer === "3"){
					if(BlockChange.front[player.pos.hover.y]===undefined||BlockChange.front[player.pos.hover.y]===null){
						for(i=0;i<(player.pos.hover.y-BlockChange.middle.length);i++){
							BlockChange.front.push(["017"]);
						}
						BlockChange.front[player.pos.hover.y][0] = sessionStorage.getItem("pickedBlock");
					}else{
						BlockChange.front[player.pos.hover.y][player.pos.hover.x] = sessionStorage.getItem("pickedBlock");
					}
				}
				localStorage.setItem("world-"+world.value,JSON.stringify(BlockChange));
			}
		}
	}
}
function tool(type){
	let ToolSize = 24;
	if(type == "block"){
		if(sessionStorage.getItem("pickedBlock") !== null || sessionStorage.getItem("layer") !== null){
			ctx.beginPath();
			ctx.strokeStyle = "black";
			ctx.lineWidth = 1;
			ctx.rect(player.pos.mouse.x+(ToolSize)/2, player.pos.mouse.y-(ToolSize)*1.5, (ToolSize), (ToolSize));
			ctx.stroke();
			image("blocks/tile"+sessionStorage.getItem("pickedBlock"), player.pos.mouse.x+(ToolSize), player.pos.mouse.y-(ToolSize), (ToolSize), (ToolSize));
			ctx.fillStyle = "darkgrey";
			canvasText(sessionStorage.getItem("layer"),player.pos.mouse.x+(ToolSize)*1.5,player.pos.mouse.y-(ToolSize),20);
		}
	}
}
function blockFunction(){
	//space
	if(player.switchWorld === true){
		image("action/space",canvas.width/2,canvas.height/2-(32)-player.frame,64+Math.sin(blockAnimation.frame)*5,64+Math.sin(blockAnimation.frame)*5);
	}
}
/*               GAME               */
function image(img,x,y,width,height){
	var myImage = document.createElement('img');
	ctx.globalAlpha = 1;
	myImage.src = "../code/assets/"+img+".png";
	if(!myImage.src.includes("null") &&!myImage.src.includes(null)){
		try{
			ctx.drawImage(myImage, x-width/2, y-height/2, width,height);
		}catch{
			return("ERROR");
		}
	}
}
function saveWorld(SaveRequest){
	let SAVEDFILE = JSON.stringify(game);
	SAVEDFILE = SAVEDFILE.replace("null","127");
	localStorage.setItem("world-"+SaveRequest,SAVEDFILE);
	localStorage.setItem("player",JSON.stringify(player));
}
let treasureLoop = setInterval(function() {
	if(player.pause.paused === false){
		blockAnimation.frame = (blockAnimation.frame + 1) % blockAnimation.info.frames;
		if(blockAnimation.frame > blockAnimation.info.frames){blockAnimation.frame=blockAnimation.info.frames;}
	}
},player.animationSpeed/4);

/*               CANVAS CONTROLS               */
canvas.ondblclick = function(event){
	if(gameInfo.player.lock.isOn === false && gameInfo.player.lock.shortcut){
		player.pause.paused = true;
		document.getElementById("pause").setAttribute("paused",player.pause.paused);
		if(confirm("Turn on temperaty lock?")){
			gameInfo.player.lock.isOn = true;
		}
	}
};
addEventListener("visibilitychange", (event) => {
	if (document.visibilityState !== "visible"){
		player.pause.paused = true;
	}
});
/*******************************
*
*   T I M E  F O R  S N A C K
*       - Kenneth
*
*     THIS is definitely part of the code :)
*******************************/