function paused(){
    if(player.pause.paused && player.pause.reason == "paused"){
        ctx.shadowBlur = 20;
        ctx.shadowColor = "black";
        image("blocks/tile024",canvas.width/2,canvas.height/2,canvas.width,canvas.height);
        let radius = 100;
        image("web/logo-full",canvas.width/2 + (player.pos.mouse.x - canvas.width/2)/radius,canvas.height/2 + (player.pos.mouse.y - canvas.height/2)/radius,canvas.width,canvas.height);

        if(player.pos.mouse.x > canvas.width/2 - (64) && player.pos.mouse.x < canvas.width/2 + (64) && player.pos.mouse.y > canvas.height/2 - (64) && player.pos.mouse.y < canvas.height/2 + (64)){
            image("action/start",canvas.width/2,canvas.height/2, 160,160);
            if(player.pos.mouse.click){
                if(gameInfo.player.lock.isOn){
                    let password = prompt("PIXLUS has been locked.\nPlease enter your PIXLUS password:", "");
                    if(password == gameInfo.player.password){
                        gameInfo.player.lock.isOn = false;
                        player.pause.paused = false;
                        setCursor("clickable");
                    }
                }else{
                    player.pause.paused = false;
                    setCursor("clickable");
                }
            }
        }else{
            image("action/start",canvas.width/2,canvas.height/2,128,128);
        }

        if(player.pos.mouse.x > canvas.width/1.5 - (128/2) && player.pos.mouse.x < canvas.width/1.5 + (128/2) && player.pos.mouse.y > canvas.height/1.5 - (128/2) && player.pos.mouse.y < canvas.height/1.52 + (128/2)){
            canvas.style.title = "Controls";
            image("icons/keys",canvas.width/1.5,canvas.height/1.5,128*1.25,128*1.25);
            if(player.pos.mouse.click){
                window.open("./guide/controls.html");
                window.close();
            }
            player.pos.mouse.click = false;
        }else{
            image("icons/keys",canvas.width/1.5,canvas.height/1.5,128,128);
        }

        ctx.font = "8px Archivo Black";
        ctx.fillStyle = "black";
        ctx.fillText("Credits",30,canvas.height - 30);
        if(player.pos.mouse.x < 100 && player.pos.mouse.y > canvas.height-38){
            if(player.pos.mouse.click){
                window.location = "credits.html";
            }
        }
        ctx.shadowBlur = 0;
        canvas.removeAttribute("title",);
    }
    player.pos.mouse.click = false;
}
function wait(ms){
    var start = new Date().getTime();
    var end = start;
    while(end < start + ms) {
        end = new Date().getTime();
   }
}
//     NOTIFICATION
function sendNotification(text,duration,repeatable){
	if(!player.notifications.past.includes(text) && !player.notifications.active.includes(text)){
		player.notifications.active.push(text);
		let notificationLoop;
		notificationLoop = setInterval(function() {
			if(player.notifications.notificationState === duration){
				if(!repeatable){
					player.notifications.past.push(player.notifications.active[0]);
				}
				player.notifications.active.splice(0, 1)
			}
			if(player.notifications.active.length > 0){
				player.notifications.notificationState = 1;
			}else{
				player.notifications.notificationState = 0;
			}
		},1000);
	}
}
function notification(){
    let size={x:32*6,y:16*5};
			let pos={x:canvas.width/3*2,y:size.y/2}
			ctx.shadowBlur = 20;
			ctx.shadowColor = "black";
			image("icons/notification",pos.x,pos.y,size.x,size.y,15);
            ctx.fillStyle = "black";
            canvasText("NOTIFICATION",pos.x,pos.y/1.5)
			canvasText(player.notifications.active[0],pos.x,pos.y,10)
            ctx.shadowBlur = 0;
			ctx.shadowColor = "black";
}
function speechMode(state,playerTalkingTue,character,text){
    if(state){
        player.pause.paused = true;
        player.pause.reason = "speech";
        player.lastKey = null;
        speech(playerTalkingTue,character,text);
    }else{
        player.pause.paused = false;
    }
}
function speech(playerTalkingTue,character,text){
    let playerImage = "player/idle/right/frame_"+player.frame;

    ctx.shadowBlur = 0;
	ctx.shadowColor = "black";
    image("blocks/tile024",canvas.width/2,canvas.height/2,canvas.width,canvas.height);
    image(playerImage, 142, canvas.height-252,500,500);
    if(playerTalkingTue){
        image("action/speech/Speech:1",canvas.width/2,canvas.height/2,canvas.width*-1,canvas.height);
        canvasText(gameInfo.player.name,200,canvas.height-125,50);
    }else{
        image("action/speech/Speech:2",canvas.width/2,canvas.height/2,canvas.width*-1,canvas.height);
        canvasText(character,canvas.width-200,canvas.height-125,50);
    }
    canvasText(text,150,canvas.height-90,25);
}
function canvasText(text,x,y,size){
    ctx.font = size+"px Archivo Black";
    ctx.fillText(text,x,y);
}