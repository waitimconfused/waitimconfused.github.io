function load(){
  if(!gameInfo.player.lock.isOn){
    LoadWorld(1);
    LoadWorld(2);
  }else{
    let password = prompt("PIXLUS has been locked.\nPlease enter your PIXLUS password:", "");
    if(password == gameInfo.player.password){
        gameInfo.player.lock.isOn = false;
        load();
    }
  }
}

window.onload = function(){
	player.pos.x = player.pos.start.x;
	player.pos.y = player.pos.start.y;
}

function LoadWorld(world){
  let LoadSave = prompt("Please enter save code from file: `pixlus-world_save_"+world+".txt`");
  let QuestionSave = window.atob(LoadSave);
  if(QuestionSave.includes(`"back_fill":"214"`)){
    document.getElementById("world").value = 2;
    localStorage.setItem("world-"+world,QuestionSave);
    player.pause.paused = true;
    player.pause.reason = "paused";
  }else{
    alert("Unproper Save.");
  
  }
}