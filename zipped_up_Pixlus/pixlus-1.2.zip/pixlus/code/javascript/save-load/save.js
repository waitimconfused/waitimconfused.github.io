var save = document.getElementById("save");

save.addEventListener("click", function(){
	DownloadWorld(1);
	DownloadWorld(2);
});

window.addEventListener('onbeforeunload', function(){
	let SAVEDFILE = JSON.stringify(game);
	SAVEDFILE = SAVEDFILE.replace("null","127");
	localStorage.setItem("world-"+world.value,SAVEDFILE);
	localStorage.setItem("player",JSON.stringify(player));
});
function DownloadWorld(world){
	var element = document.createElement('a');
	element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(
		window.btoa(
			JSON.stringify(localStorage.getItem("world-"+world))
		)
	));
	element.setAttribute('download', "pixlus-world_save|"+world+".txt");
	element.style.display = 'none';
	document.body.appendChild(element);
	element.click();
	document.body.removeChild(element);
}