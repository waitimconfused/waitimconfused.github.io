var gameInfo = {
	devModeTrue: false,
	mapCreator: false,
	player: {
		name: "Defult Name",
		password: "PIXLUS_password",
		lock: {
			isOn: false,
			shortcut: false,
		},
	},
};