if(window.name !== "pixlus"){
    window.close();
}
function reset(){
    localStorage.clear();
    window.close();
}
document.getElementById("player_name").innerHTML = gameInfo.player.name;