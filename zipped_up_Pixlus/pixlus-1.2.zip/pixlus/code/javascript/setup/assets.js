/* Here is the block count. Changing it affects the amount of blocks able to be used in PIXLUS. */
	let blockCount = Object.keys(blockDatabase).length - 1;
/* Nothing else to change here! */

try{
	title("Blocks","assets");
	var idx = 0;
	for (let i = 0; i < blockCount/14; i++) {
		for (let ie = 0; ie < 18; ie++){ 
			if(idx < blockCount+1){
					var block = idx;
				if(idx < 100){
					var block = "0"+JSON.stringify(idx);
					if(idx < 10){
						var block = "00"+JSON.stringify(idx);
					}
				}
				var img = '../code/assets/blocks/tile'+block+'.png';
				let x = document.createElement("IMG");
				x.setAttribute("src", img);
				x.setAttribute("width", "24");
				x.setAttribute("height", "24");
				x.setAttribute("alt", "render-v2.block:"+block);
				x.setAttribute("title",blockName(block)+" :|: Layer: "+blockLayer(block));
				x.setAttribute("id",block);
				x.setAttribute("onclick",'blockPicked(this.getAttribute("id"))');
				x.setAttribute("ondrag",'blockPicked(this.getAttribute("id"))');
				x.setAttribute("onerror","this.setAttribute('onclick',null); this.setAttribute('ondrag',null); this.src='../code/assets/icons/blank.png'");

				document.getElementById("assets").appendChild(x);

				let y = document.createElement("IMG");
				y.setAttribute("src", img);
				y.setAttribute("width", "24");
				y.setAttribute("height", "24");
				y.setAttribute("alt", "render-v2.block:"+block);
				y.setAttribute("title",blockName(block)+" :|: Layer: "+blockLayer(block));
				y.setAttribute("id",block);
				y.setAttribute("onclick",'blockPicked(this.getAttribute("id"))');
				y.setAttribute("ondrag",'blockPicked(this.getAttribute("id"))');
				y.setAttribute("onerror","this.setAttribute('onclick',null); this.setAttribute('ondrag',null); this.src='../code/assets/icons/blank.png'");
				document.getElementById("invontory").appendChild(y);

				idx += 1;
			}
		}
		lineBreak("invontory");
	}
	/*     PLAYER     */
	//   Right
	title("Player","assets");
	var idx = 0;
	for(let iee = 0; iee < 4; iee++){
		loadImg('../code/assets/player/idle/right/frame_'+idx+'.png','idx','render-v2.player.frame:"+idx',true);
		loadImg('../code/assets/player/idle/left/frame_'+idx+'.png','idx','render-v2.player.frame:"+idx',true);
			idx += 1;
	}
	lineBreak("assets");
	var idx = 0;
	for(let iee = 0; iee < 6; iee++){
		loadImg('../code/assets/player/walk/right/frame_'+idx+'.png',idx,'render-v2.player.frame:"+idx',true);
		loadImg('../code/assets/player/walk/left/frame_'+idx+'.png',idx,'render-v2.player.frame:"+idx',true);
			idx += 1;
	}
	title("Animated Menus","assets");
	//   Treasure Box
	var idx = 0;
	for(let iee = 0; iee < 8; iee++){
		loadImg('../code/assets/icons/treasure_box/frame'+idx+'.png',"treasure:shine;frame:"+idx,'render-v2.player.frame:"+idx',true);
			idx += 1;
	}

	title("Icons","assets");

	loadImg('../code/assets/action/space.png','action:space_bar',null);
	loadImg('../code/assets/action/alert.png','action:alert',null);
	loadImg('../code/assets/action/speech/Speech-1.png','icons:notification',null);
	loadImg('../code/assets/action/speech/Speech-2.png','icons:notification',null);
	loadImg('../code/assets/icons/hover.png','icons:hover',null);
	loadImg('../code/assets/icons/hover-decline.png','icons:hover',null);
	loadImg('../code/assets/icons/keys.png','icons:keys',null);
	loadImg('../code/assets/web/logo-full.png','icons:background',null);
	loadImg('../code/assets/icons/notification.png','icons:notification',null);
}
catch{
	// Stops errors in Console
}


/*     FUNCTIONS     */
function title(txt,id){
	let title = document.createElement("p");
	title.innerHTML = txt;
	document.getElementById(id).appendChild(title);
}
function lineBreak(id){
	if(document.getElementById(id).lastChild.getAttribute("class") !== "seporator"){
		var y = document.createElement("BR");
		y.setAttribute("class","seporator");
		document.getElementById("assets").appendChild(y);
	}
}
function loadImg(link,title,alt){
	var y = document.createElement("IMG");
	y.setAttribute("src", link);
	y.setAttribute("width", "24");
	y.setAttribute("height", "24");
	y.setAttribute("alt", alt);
	y.setAttribute("title",title);
	y.setAttribute("onerror","this.src='../code/assets/icons/blank.png'");
	document.getElementById("assets").appendChild(y);
}

function blockPicked(block){
	if(block < blockCount+1){
		sessionStorage.setItem("layer",blockDatabase[block].layer);
		sessionStorage.setItem("pickedBlock", block);
	}
}

function blockLayer(indx){
	if(blockDatabase.hasOwnProperty(indx)){
		if(blockDatabase[indx].layer < 4){
			return(blockDatabase[indx].layer);
		}else{
			return(3);
		}
	}else{
		return("No Defult Layer");
	}
}
function blockName(indx){
	if(blockDatabase.hasOwnProperty(indx)){
		return(blockDatabase[indx].name);
	}else{
		return("Un-named Tile");
	}
}