# VERSION 3

`It's so hot. So Loud, but quiet.`
`You open your eyes and all you see is fire. You turn around and see a dark, distorted figure.`

Hello, it seems as though you have found this place.

> Who are you?

Somethings, are better to not know.

> Where am I?

Great question.

> What happened?

I cannot tell you. But soon you will remember.

> Who are you?

You can visit me; As long as it works.

> What?

Nevermind. You are free to go now.
