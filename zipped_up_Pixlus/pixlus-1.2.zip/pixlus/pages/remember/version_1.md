# VERSION 1

```You find yourself in a cloudy place, no recollection of who you are.
You learn that you have died, and you return to your home town to try to figure out who you were.
While there, you help your townfolk, and in return, they give you blocks.
You can use these blocks in the ghost world to make it your own.
