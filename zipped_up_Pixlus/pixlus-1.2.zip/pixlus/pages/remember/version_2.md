# VERSION 2

`You wake up an a cloudy place, calm music playing. It smells so sweet, and it makes you hungry. You have no idea where you are, or who you are. You open your eyes, and see a figure standing above you. You wonder who he is.`

I am the god of the resting place. You, my friend have died.

`Somehow, without saying anything, you can hear the figures voice.`

> What?

You died. What don't you understand?"
> "How did I die?"

Phh, I dunno. I have to do a lot of work up here.

> Could I go back?

I guess... But you could do whatever you want here, you can build whatever you want!

> No point. I have nothing with me." You have your mind set on going back home to figure out who you were.

Also, whoever I let go back to their world, has to do some help there.

`No idea who you are, and you are being forced to help out people you can't remember. You were told that the way between worlds was the gateway. You should probably head there now.`
