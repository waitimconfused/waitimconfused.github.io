var save = document.getElementById("save");

save.addEventListener("click", function(){
	var element = document.createElement('a');
	element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(
		JSON.stringify(game)
	));
	element.setAttribute('download', "pixlus-world_save.txt");
	element.style.display = 'none';
	document.body.appendChild(element);
	element.click();
	document.body.removeChild(element);
});

window.addEventListener('beforeunload', function (e) {
	localStorage.setItem("world-2",JSON.stringify(game));
});