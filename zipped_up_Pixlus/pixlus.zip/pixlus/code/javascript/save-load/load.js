var inputFile = document.getElementById('inputfile');
inputFile.addEventListener('change', function() {
	var fr = new FileReader();
	alert(localStorage.getItem("world-2"));
	fr.onload = function(){
		if(text.includes('"{\"back_fill\":[\"')){
			localStorage.setItem("world-2",fr.result)
			alert(localStorage.getItem("world-1"));
		}
	}
})

window.onload = function(){
	player.pos.x = player.pos.start.x;
	player.pos.y = player.pos.start.y;
}