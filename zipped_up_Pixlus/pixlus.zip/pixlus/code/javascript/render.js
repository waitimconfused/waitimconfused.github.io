const id = "display";
var canvas = document.getElementById(id);
var ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;

/*     NOTE
*  The image ['024'] is a placeholder for an empty slot.
*  The image['000'] is allready in use, so I am using a image that will never exist.
*/
sessionStorage.setItem("layer","middle");
var world = document.getElementById("world").innerHTML;
var game = JSON.parse(localStorage.getItem("world-"+world));
var player = {
	paused: false,
	frame: 1,
	pos: {
		x: 10,
		y: 3,
		hover: {
			x: 0,
			y: 0
		},
		mouse: {
			x: 0,
			y: 0,
			click: false,
		},
		start:{
			x: 10,
			y: 3,
		},
	},
	direction:"left",
	movement: "idle",
	speed: 0.25,
	fps:24,
	invontory:{

	}
}
var gameLoop = setInterval(function() {
	var PlayerPos={x:Math.round(player.pos.y),y:Math.round(player.pos.x)};
		var PlayerBlock={
			back:game.back[PlayerPos.x][PlayerPos.y],
			middle:game.middle[PlayerPos.x][PlayerPos.y],
			front:game.front[PlayerPos.x][PlayerPos.y],
		};
	ctx.globalAlpha = 1;
	if(player.paused === false){
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		render();
		blockFunction();
	}else{
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.globalAlpha = 0.5;
		ctx.fillStyle = "lightblue"; 
		ctx.fillRect(0, 0, canvas.width,canvas.height);

		var button = {
			x:canvas.width/2,
			y:canvas.height/3,
			s:64*1.5
		};
		image("action-button-back",button.x,button.y,button.s);
		if(buttonHoverState(button.x,button.y,button.s)){
			image("action-button-play",button.x,button.y,button.s);
		}else{
			image("action-button-pause",button.x,button.y,button.s);
		}
		var button = {
			x:canvas.width/2.5,
			y:canvas.height/2.5,
			s:64
		};
		image("action-button-back",button.x,button.y,button.s);
		if(buttonHoverState(button.x,button.y,button.s)){
			image("action-button-home",button.x,button.y-5,button.s);
		}else{
			image("action-button-home",button.x,button.y,button.s);
		}
	}
	function buttonHoverState(x,y,s){
		return(player.pos.mouse.x > x - s/2 && player.pos.mouse.x < x + s/2 && player.pos.mouse.y > y - s*0.5 && player.pos.mouse.y < y + s*0.5)
	}
	function render(){
		var world = document.getElementById("world").innerHTML;
		var game = JSON.parse(localStorage.getItem("world-"+world));
		blocks(player.pos.x,player.pos.y,game.size,true);
		ctx.font = "30px Arial";
		ctx.fillText(world,50,50);
	}

	function blocks(posX,posY,size,hilightHoveredBlock){
		for(var backY = 0; backY < canvas.height/(size*16)+1; backY++){
			for(var backX = 0; backX < canvas.width/(size*16)+1; backX++){
				image(game.back_fill, backX*(size*16), backY*(size*16),(size*16));
			}
		}
		for(var backY = 0; backY < game.back.length; backY++){
			for(var backX = 0; backX < game.back[backY].length; backX++){
				var icon = game.back[backY][backX];
				var backPosX = (backX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
				var backPosY = (backY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
				if(backPosX < canvas.width + 16 * game.size && backPosX > 0 - 16 * game.size){
					if(backPosY < canvas.height + 16 * game.size && backPosY > 0 - 16 * game.size){
						image(icon, backPosX, backPosY,(size*16));
					}
				}
			}
		}
		var playerShow = false;
		for(var middleY=0;middleY < game.middle.length;middleY++){
			for(var middleX = 0; middleX < game.middle[middleY].length; middleX++){
				var icon = game.middle[middleY][middleX];
				var middlePosX = (middleX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
				var middlePosY = (middleY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
				if(middlePosX < canvas.width + 16 * game.size && middlePosX+1 > 0 - 16 * game.size){
					if(middlePosY < canvas.height + 16 * game.size && middlePosY > 0 - 16 * game.size){
						image(icon, middlePosX, middlePosY,(size*16));
					}
				}
			}
		}
		image(player.frame,canvas.width/2, canvas.height/2,(size*16));
		for(var frontY = 0; frontY < game.front.length; frontY++){
			for(var frontX = 0; frontX < game.front[frontY].length; frontX++){
				var icon = game.front[frontY][frontX];
				var frontPosX = (frontX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
				var frontPosY = (frontY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
			
				if(frontPosX < canvas.width + 16 * game.size && frontPosX > 0 - 16 * game.size){
					if(frontPosY < canvas.height + 16 * game.size && frontPosY > 0 - 16 * game.size){
						image(icon, frontPosX, frontPosY,(size*16));
					}
				}
			}
		}
			var hoverPosX = (player.pos.hover.x*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
			var hoverPosY = (player.pos.hover.y*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
			ctx.beginPath();
			ctx.lineWidth = "5";
			image(icon, player.pos.hover.x, player.pos.hover.y,(size*16));
			if(hilightHoveredBlock){
				if(player.pos.hover.x < 0 || player.pos.hover.y < 0){
					ctx.strokeStyle = "darkred";
				}else{
					ctx.strokeStyle = "darkgrey";
				}
			}
			ctx.rect(hoverPosX-16*game.size/2,hoverPosY-16*game.size/2,16*game.size,16*game.size);
			ctx.stroke();
			if(7<3){playerKill();}
	}

	function playerKill(reason){
		if(reason === "position"){
			if(player.pos.x < 0){
				player.pos.x = 0;
			}
		}else{
			player.pos.x = player.pos.start.x;
			player.pos.y = player.pos.start.y;
		}
	}
	function blockFunction(runAction){
		let action = {
			space: ["080","085","156"],
			alert: ["061"],
		};
		//space
		if(action.space.includes(PlayerBlock.back)){
			image("action-space",canvas.width/2+1,canvas.height/2-(8*game.size)-player.frame,16*game.size);
		}if(action.space.includes(PlayerBlock.middle)){
			image("action-space",canvas.width/2+1,canvas.height/2-(8*game.size)-player.frame,16*game.size);
		}if(action.space.includes(PlayerBlock.front)){
			image("action-space",canvas.width/2+1,canvas.height/2-(8*game.size)-player.frame,16*game.size);
		}if(runAction ==="spaceBar"){
			alert("Entering Zone...");
		}
		//alert
		if(action.alert.includes(PlayerBlock.back)){
			image("action-alert",canvas.width/2+1,canvas.height/2-(8*game.size)-player.frame,16*game.size);
		}if(action.alert.includes(PlayerBlock.middle)){
			image("action-alert",canvas.width/2+1,canvas.height/2-(8*game.size)-player.frame,16*game.size);
		}if(action.alert.includes(PlayerBlock.front)){
			image("action-alert",canvas.width/2+1,canvas.height/2-(8*game.size)-player.frame,16*game.size);
		}
	}
	canvas.addEventListener("mousedown", function(e){player.pos.mouse.click = true});
	canvas.addEventListener("mouseup", function(e){player.pos.mouse.click = false});

	if(player.pos.mouse.click){
		var layer = sessionStorage.getItem("layer");
		if(sessionStorage.getItem("layer") === 'null'){
			var layer = localStorage.getItem("pickedBlock");
			var layer = document.getElementById(layer);
			var layer = layer.getAttribute("layer");
		}
		if(layer === "1"){
			if(game.back[player.pos.hover.y]===undefined||game.back[player.pos.hover.y]===null&&game.back.player.pos.hover.y>0){
				for(i=0;i<(player.pos.hover.y-game.back.length);i++){
					game.back.push([null]);
				}
				game.back[player.pos.hover.y][0] = localStorage.getItem("pickedBlock");
			}else{
				game.back[player.pos.hover.y][player.pos.hover.x] = localStorage.getItem("pickedBlock");
			}
		}else if(layer === "2"){
			if(player.pos.hover.y > game.middle.length){
				for(i=0;i<game.middle.length;i++){
					game.middle.push("000");
				}
			}else{
				game.middle[player.pos.hover.y][player.pos.hover.x] = localStorage.getItem("pickedBlock");
			}
		}else if(layer === "3"){
			if(game.front[player.pos.hover.y]===undefined||game.front[player.pos.hover.y]===null&&game.front.player.pos.hover.y>0){
				for(i=0;i<(player.pos.hover.y-game.front.length);i++){
					game.front.push([null]);
				}
			}else{
				game.front[player.pos.hover.y][player.pos.hover.x] = localStorage.getItem("pickedBlock");
			}
		}
	}
},1000/player.fps);

/*               GAME               */
function image(img,x,y,size){
	if(img !== null && img !== "null" && img !== undefined && img !== "undefined"){
		var myImage = document.createElement('img');
		ctx.globalAlpha = 1;
		myImage.src = 'code/assets/blocks/tile'+img+'.png';

			if(img === player.frame){
				ctx.globalAlpha = 0.75;
				if(player.movement === "idle"){
					myImage.src = 'code/assets/player/idle/'+player.direction+'/frame_'+player.frame+'.png';
				}else{
					myImage.src = 'code/assets/player/walk/'+player.direction+'/frame_'+player.frame+'.png';
				}
			}
			if(img === "action-space"){
				myImage.src = 'code/assets/action/space.png';
			}
			if(img === "action-alert"){
				myImage.src = 'code/assets/action/alert.png';
			}
			if(img === "action-button-back"){
				myImage.src = 'code/assets/action/button/back.png';
			}
			if(img === "action-button-pause"){
				myImage.src = 'code/assets/action/button/pause.png';
			}
			if(img === "action-button-play"){
				myImage.src = 'code/assets/action/button/play.png';
			}
			if(img === "action-button-home"){
				myImage.src = 'code/assets/action/button/home.png';
			}

		ctx.drawImage(myImage, x-size/2, y-size/2, size, size);
	}
}

var playerLoop = setInterval(function() {
	if(player.paused === false){
		if(player.movement === "idle"){
			player.frame = (player.frame + 1) % 3;
		}else{
			player.frame = (player.frame + 1) % 5
		}
	}
},250);

/*               CANVAS CONTROLS               */
var mousePos = setInterval(function(e) {
	canvas.addEventListener("mousemove", function(e){
		var innerMouse = {
			X: e.x,
			Y: e.y
		};
		player.pos.mouse.x = e.x;
		player.pos.mouse.y = e.y;
		var MouseBlockX = Math.round((innerMouse.X - 390) / 16 / game.size + player.pos.x);
		var MouseBlockY = Math.round((innerMouse.Y - 390) / 16 / game.size + player.pos.y);
		player.pos.hover.x = MouseBlockX;
		player.pos.hover.y = MouseBlockY;
		canvas.setAttribute("title",player.pos.hover.x+"|-|"+player.pos.hover.y);
	});
},1000/player.fps);

var playerLoop = setInterval(function() {
	if(player.paused === false){
		player.frame = (player.frame + 1) % 3;
	}else{
		player.frame = (player.frame + 1) % 5;
	}
},250);

addEventListener("keydown", function(e){
	let key = e.key;
	if(key == "Escape"){
		if(player.paused){
			player.paused = false;
		}else{
			player.paused = true;
		}
	}
	if(player.paused !== true){
		let block={back: game.back[Math.ceil(player.pos.y)][Math.round(player.pos.x)],middle:game.middle[Math.ceil(player.pos.y)][Math.round(player.pos.x)],};
		if(key.toLowerCase() === 'w'){
			player.pos.y -= player.speed;
			player.movement = "walk";
			if(player.pos.y < 0){
				player.movement = "idle";
				player.pos.y +=player.speed;
			}
		}
		if(key.toLowerCase() === 's'){
			player.pos.y += player.speed;
			player.movement = "walk";
			if(player.pos.y > game.middle[Math.round(player.pos.y)].length-1){
				player.movement = "idle";
				player.pos.y -=player.speed;
			}
		}
		if(key.toLowerCase() === 'a'){
			player.direction = "left";
			player.pos.x -= player.speed;
			player.movement = "walk";
			if(player.pos.x < 0){
				player.movement = "idle";
				player.pos.x +=player.speed;
			}
		}
		if(key.toLowerCase() === 'd'){
			player.direction = "right";
			player.pos.x += player.speed;
			player.movement = "walk";
			if(player.pos.x > game.middle[Math.round(player.pos.y)].length-1){
				player.movement = "idle";
				player.pos.x -=player.speed;
			}
		}
	}
	if(key === "1"){
		sessionStorage.setItem("layer","1");
		document.getElementById("blockLayer").innerHTML = sessionStorage.getItem("layer");
	}
	if(key === "2"){
		sessionStorage.setItem("layer","2");
		document.getElementById("blockLayer").innerHTML = sessionStorage.getItem("layer");
	}
	if(key === "3"){
		sessionStorage.setItem("layer","3");
		document.getElementById("blockLayer").innerHTML = sessionStorage.getItem("layer");
	}
	if(key.toLowerCase() == 't' || key == 'T'){
		blockFunction("spaceBar");
		this.alert("Pressed Spacebar");
	}
});

addEventListener("keyup", function(e){
	player.movement = "idle";
});
/*******************************
*
*   T I M E  F O R  S N A C K
*       - Kenneth
*
*     THIS is definitely part of the code :)
*******************************/