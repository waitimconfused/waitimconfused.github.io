blockPicked("017");
var idx = 0;
for (let i = 0; i < 14; i++) {
	for (let ie = 0; ie < 18; ie++){
		if(idx < 240){
			let x = document.createElement("IMG");
				var block = idx;
			if(idx < 100){
				var block = "0"+JSON.stringify(idx);
				if(idx < 10){
					var block = "00"+JSON.stringify(idx);
				}
			}
			var img = 'code/assets/blocks/tile'+block+'.png';
			x.setAttribute("src", img);
			x.setAttribute("width", "24");
			x.setAttribute("height", "24");
			x.setAttribute("alt", "render-v2.block:"+block);
			x.setAttribute("title","Block: "+block+"--Layer: "+blockLayer(idx));
			x.setAttribute("id",block);
			x.setAttribute("block",block);
			x.setAttribute("layer",blockLayer(idx));
			x.setAttribute("onclick",'blockPicked(this.getAttribute("block"))');
			x.webkitImageSmoothingEnabled = false;
			x.mozImageSmoothingEnabled = false;
			x.imageSmoothingEnabled = false;
			document.getElementById("blocks").appendChild(x);
			idx += 1;
		}
	}
	var y = document.createElement("BR");
	y.setAttribute("class","seporator");
	document.getElementById("blocks").appendChild(y);
}
function blockPicked(block){
	sessionStorage.setItem("layer",blockLayer(block));
	localStorage.setItem("pickedBlock", block);
	let selectBlock = document.getElementById("selectBlock");
	let img = "code/assets/blocks/tile"+localStorage.getItem("pickedBlock")+".png"
	selectBlock.setAttribute("src",img);
	document.getElementById("blockLayer").innerHTML = sessionStorage.getItem("layer");
}
function blockLayer(indx){
	if(indx < 12){
		return("2");
	}else if(indx > 11 && indx < 18){
		return("3");
	}else if(indx > 17 && indx < 24){
		return("2");
	}else if(indx == 24){
		return("1");
	}else if(indx > 24 && indx < 30){
		return("2");
	}else if(indx > 29 && indx < 36){
		return("3");
	}else if(indx > 35 && indx < 48){
		return("2");
	}else if(indx > 47 && indx < 54){
		return("3");
	}else if(indx > 53 && indx < 99){
		if(indx === 81){return("1")}else{return ("2")}
	}else if(indx > 98 && indx < 104){
		return("3");
	}else if(indx > 103 && indx < 117){
		if(indx === 130){return("1")}else{return("2")}
	}else if(indx > 116 && indx < 122){
		return("3");
	}else if(indx > 121 && indx < 162){
		return("2");
	}else if(indx > 161 && indx < 164){
		return("3");
	}else if(indx === 164){
		return("2");
	}else if(indx > 164 && indx < 172){
		return("3");
	}else if(indx > 171 && indx < 182){
		return("2");
	}else if(indx > 181 && indx < 187){
		return("3");
	}else if(indx > 186 && indx < 195){
		return("2");
	}else if(indx > 194 && indx < 198){
		return("1");
	}else if(indx > 197 && indx < 201){
		return("3");
	}else if(indx > 200 && indx < 213){
		return("2");
	}else if(indx > 212 && indx < 216){
		return("1");
	}else if(indx > 215 && indx < 231){
		return("2");
	}else if(indx > 230 && indx < 240){
		return("1");
	}else{
		return("error-layerNotSet");
	}
}
/*     PLAYER     */
//   Right
var idx = 0;
for(let iee = 0; iee < 4; iee++){
	saveImg('code/assets/player/idle/right/frame_'+idx+'.png','idx','render-v2.player.frame:"+idx',true);
	saveImg('code/assets/player/idle/left/frame_'+idx+'.png','idx','render-v2.player.frame:"+idx',true);
		idx += 1;
}
var idx = 0;
for(let iee = 0; iee < 6; iee++){
	saveImg('code/assets/player/walk/right/frame_'+idx+'.png',idx,'render-v2.player.frame:"+idx',false);
	saveImg('code/assets/player/walk/left/frame_'+idx+'.png',idx,'render-v2.player.frame:"+idx',false);
		idx += 1;
}

saveImg('code/assets/action/space.png','action:space_bar',null,true);
saveImg('code/assets/action/alert.png','action:alert',null,true);
saveImg('code/assets/action/button/back.png','action:button-back',null,true);
saveImg('code/assets/action/button/pause.png','action:button-pause',null,true);
saveImg('code/assets/action/button/play.png','action:button-play',null,true);
saveImg('code/assets/action/button/home.png','action:button-home',null,true);

saveImg('code/assets/icons/GameBackground.png','action:button-home',null,false);

function saveImg(link,title,alt,hidden){
	var y = document.createElement("IMG");
	y.setAttribute("src", link);
	y.setAttribute("width", "36");
	y.setAttribute("height", "36");
	y.setAttribute("alt", alt);
	y.setAttribute("title",title);
	if(hidden){
		y.setAttribute("class","hidden");
	}
	document.getElementById("blocks").appendChild(y);
}